let div    = document.querySelector('div');
let button = document.querySelector('button');
q.addEventListener('click', function() {
    fetch('http://localhost:8080/ajax.html').then(
        response => {
            return response.text();
        }
    ).then(
        text => {
            div.innerHTML = text;
        }
    );
});
q1.addEventListener('click', function() {
    fetch('http://localhost:8080/ajax1.html').then(
        response => {
            return response.text();
        }
    ).then(
        text => {
            div.innerHTML = text;
        }
    );
});

q2.addEventListener('click', function() {
    fetch('http://localhost:8080/ajax2.html').then(
        response => {
            return response.text();
        }
    ).then(
        text => {
            div.innerHTML = text;
        }
    );
});



